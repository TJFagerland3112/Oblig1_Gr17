package no.hvl.dat102.filmarkiv.klient;

import no.hvl.dat102.filmarkiv.adt.FilmarkivADT;
import no.hvl.dat102.filmarkiv.impl.Film;
import no.hvl.dat102.filmarkiv.impl.Sjanger;

import java.util.Arrays;
import java.util.Scanner;

import static no.hvl.dat102.filmarkiv.impl.Sjanger.sjanger.*;

public class Tekstgrensesnitt {

    // Leser inn opplysninger om en film fra tastatur og returnere et Film-objekt
    public Film lesFilm() {
// TODO
        Scanner leser = new Scanner(System.in);

        //filmNr
        System.out.print("film nummer: ");
        int filmNr = leser.nextInt();
        leser.nextLine();
        //produsent
        System.out.print("produsent: ");
        String produsent = leser.nextLine();
        //filmNavn
        System.out.print("film navn: ");
        String filmNavn = leser.nextLine();
        //aar
        System.out.print("aar: ");
        int aar = leser.nextInt();
        leser.nextLine();
        //sjanger
        System.out.print("sjanger: ");
        Sjanger.sjanger filmSjanger = null;
        try {
            String input = leser.nextLine().trim().toUpperCase();
            filmSjanger = Sjanger.sjanger.valueOf(input);
        } catch (IllegalArgumentException e) {
            System.out.println("Ugyldig sjanger! Velg mellom: " + Arrays.toString(Sjanger.sjanger.values()));
        }
        //selskap
        System.out.print("selskap: ");
        String selskap = leser.nextLine();

        return new Film(filmNr, produsent, filmNavn, aar, filmSjanger, selskap);
    }
    // Skriver ut en film med alle opplysninger på skjerm (husk tekst for sjanger)
    public void skrivUtFilm(Film film) {
// TODO
        if (film == null) {
            System.out.println("Ingen filmer funnet.");
            return;
        }
        System.out.println("film nummer: " + film.getFilmNr() + ", produsent: " + film.getProdusent() + ", tittel: " + film.getFilmNavn() + ", utgivelses år: " + film.getAar() + ", sjanger: " + film.getSjanger().toString() + ", utgitt av: " + film.getSelskap());
    }
    // Skriver ut alle filmer med en spesiell delstreng i tittelen
    public void skrivUtFilmDelstrengITittel(FilmarkivADT arkiv, String delstreng) {
// TODO
        Film[] tittelfilm = arkiv.soekTittel(delstreng);
        if (tittelfilm.length == 0) {
            System.out.println("Ingen filmer funnet med denne tittelen.");
            return;
        }
        for (Film film : tittelfilm) {
            skrivUtFilm(film);
        }

    }
    // Skriver ut alle Filmer av en produsent (produsent er delstreng)
    public void skrivUtFilmProdusent(FilmarkivADT arkiv, String delstreng) {
// TODO
        Film[] prodfilm = arkiv.soekProdusent(delstreng);
        if (prodfilm.length == 0) {
            System.out.println("Ingen filmer funnet med denne produsenten.");
            return;
        }
        for (Film film : prodfilm) {
            skrivUtFilm(film);
        }
    }
    // Skriver ut en enkel statistikk som inneholder antall filmer totalt
// og hvor mange det er i hver sjanger.
    public void skrivUtStatistikk(FilmarkivADT arkiv) {
// TODO
        System.out.println("Antall filmer: " + arkiv.antall());
        System.out.println("Antall filmer i hver sjanger; ");
        System.out.println("Action: " + arkiv.antallSjanger(ACTION));
        System.out.println("Drama: " + arkiv.antallSjanger(DRAMA));
        System.out.println("Historie: " + arkiv.antallSjanger(HISTORY));
        System.out.println("Sci-Fi: " + arkiv.antallSjanger(SCIFI));
    }
// osv ... andre metoder
}
