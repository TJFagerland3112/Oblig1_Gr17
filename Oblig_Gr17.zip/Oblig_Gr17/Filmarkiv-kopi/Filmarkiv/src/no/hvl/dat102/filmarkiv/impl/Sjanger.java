package no.hvl.dat102.filmarkiv.impl;

public class Sjanger {
    public enum sjanger {
        ACTION, DRAMA, HISTORY, SCIFI;

        public static sjanger finnSjanger(String navn) {
            for (sjanger s : sjanger.values()) {
                if (s.toString().equals(navn.toUpperCase())) {
                    return s;
                }
            }
            return null;
        }


    }

}
