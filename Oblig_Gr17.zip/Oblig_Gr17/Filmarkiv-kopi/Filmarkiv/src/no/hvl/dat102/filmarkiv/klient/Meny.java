package no.hvl.dat102.filmarkiv.klient;

import no.hvl.dat102.filmarkiv.adt.FilmarkivADT;
import no.hvl.dat102.filmarkiv.impl.Film;
import no.hvl.dat102.filmarkiv.impl.Filmarkiv;
//import no.hvl.dat102.filmarkiv.impl.Filmarkiv2;

import java.util.Scanner;

import static no.hvl.dat102.filmarkiv.impl.Sjanger.sjanger.ACTION;
import static no.hvl.dat102.filmarkiv.impl.Sjanger.sjanger.SCIFI;

public class Meny {
    private Tekstgrensesnitt tekstgr;
    private FilmarkivADT filmarkiv;

    public Meny(FilmarkivADT filmarkiv){
        tekstgr = new Tekstgrensesnitt();
        this.filmarkiv = filmarkiv;
    }
    public void start(){
// legg inn en del forhåndsdefinerte filmer for å teste metodene
// ..
// TODO
        //filmer
        Film avatar = new Film(1, "James Cameron", "Avatar", 2011, ACTION, "Sony Pictures Imageworks");
        Film indianaJones = new Film(2, "George Lucas", "Indiana Jones", 1997, ACTION, "Sony Pictures Imageworks");
        Film starWars = new Film(3, "George Lucas", "Star Wars", 1979, SCIFI, "Sony Pictures Imageworks");

        Filmarkiv filmarkivet = new Filmarkiv(100);
        //Filmarkiv2 filmarkivet = new Filmarkiv2();
        //legge inn filmer i filmarkivet
        filmarkivet.leggTilFilm(avatar);
        filmarkivet.leggTilFilm(indianaJones);
        filmarkivet.leggTilFilm(starWars);

        //metoder

        Scanner meny = new Scanner(System.in);

        System.out.println("Velkommen til filmarkivet. Velg en av menyalternativene nedenfor:");

        int valgtMeny = 0;

        while (valgtMeny != 6) {
            if (valgtMeny > 6) {
                System.out.println("Ugyldig valg. Velg en av menyalternativene nedenfor:");
            }
            System.out.println();
            System.out.println("========================================================================================================================");
            System.out.println("1. legg til film, 2. vis film etter filmnummer 3. søk film i titler, 4. søk i filmprodusenter, 5. staistikk, 6. avslutt programmet");
            System.out.print("utfør 1, 2, 3, 4, 5 eller 6: ");
            valgtMeny = meny.nextInt();
            switch (valgtMeny) {
                case 1: {
                    System.out.println();
                    System.out.println("Legg til film spesifikasjonene");
                    filmarkivet.leggTilFilm(tekstgr.lesFilm());
                    System.out.println("Film lagt til.");
                }
                break;
                case 2: {
                    System.out.println();
                    System.out.print("Skriv inn filmnummer: ");
                    int tall = meny.nextInt();
                    tekstgr.skrivUtFilm(filmarkivet.finnFilm(tall));
                } break;
                case 3: {
                    meny.nextLine();
                    System.out.println();
                    System.out.print("Skriv inn tittel: ");
                    String tittel = meny.nextLine();
                    tekstgr.skrivUtFilmDelstrengITittel(filmarkivet, tittel.toLowerCase());
                }
                break;
                case 4: {
                    meny.nextLine();
                    System.out.println();
                    System.out.print("Skriv inn produsent: ");
                    String prod = meny.nextLine();
                    tekstgr.skrivUtFilmProdusent(filmarkivet, prod);
                } break;
                case 5: {
                    System.out.println();
                    tekstgr.skrivUtStatistikk(filmarkivet);
                } break;
            }
        }
        System.out.println("Avsluttet programmet.");
        /*
        filmarkiv.leggTilFilm(tekstgr.lesFilm());
        tekstgr.skrivUtFilm(filmarkiv.finnFilm(1));
        tekstgr.skrivUtFilmDelstrengITittel(filmarkiv, "avatar");
        tekstgr.skrivUtFilmProdusent(filmarkiv, "Cameron");
        */
    }
}
