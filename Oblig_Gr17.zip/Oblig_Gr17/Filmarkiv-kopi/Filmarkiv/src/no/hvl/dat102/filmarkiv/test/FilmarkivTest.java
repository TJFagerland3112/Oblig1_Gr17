package no.hvl.dat102.filmarkiv.test;

import no.hvl.dat102.filmarkiv.impl.Film;
import no.hvl.dat102.filmarkiv.impl.Filmarkiv;
//import no.hvl.dat102.filmarkiv.impl.Filmarkiv2;
import no.hvl.dat102.filmarkiv.impl.Sjanger;
import org.junit.jupiter.api.Test;

import static no.hvl.dat102.filmarkiv.impl.Sjanger.sjanger.ACTION;
import static org.junit.jupiter.api.Assertions.*;

class FilmarkivTest {

    @Test
    void finnFilmTest() {
        Filmarkiv arkiv = new Filmarkiv(5);
        assertNull(arkiv.finnFilm(3));
    }

    @Test
    void leggTilFilmTest() {
        Filmarkiv arkiv = new Filmarkiv(3);
        Film avatar = new Film(1, "James Cameron", "Avatar", 2011, ACTION, "Sony Pictures Imageworks");
        arkiv.leggTilFilm(avatar);
        assertEquals(avatar, arkiv.finnFilm(1));
    }

    @Test
    void forMangeFilmerTest() {
        Filmarkiv arkiv = new Filmarkiv(3);
        Film avatar = new Film(1, "James Cameron", "Avatar", 2011, ACTION, "Sony Pictures Imageworks");
        Film indianaJones = new Film(2, "James Cameron", "Indiana Jones", 2011, ACTION, "Sony Pictures Imageworks");
        Film starWars = new Film(3, "James Cameron", "Star Wars", 2011, ACTION, "Sony Pictures Imageworks");
        Film matrix = new Film(4, "Wachowski", "The Matrix", 1999, ACTION, "Sony Pictures Imageworks");
        arkiv.leggTilFilm(avatar);
        arkiv.leggTilFilm(indianaJones);
        arkiv.leggTilFilm(starWars);

        //trigger
        arkiv.leggTilFilm(matrix);
        //sjekker riktig antall
        assertEquals(4, arkiv.antall());
        //alle gamle bevart
        assertSame(avatar, arkiv.finnFilm(1));
        assertSame(indianaJones, arkiv.finnFilm(2));
        assertSame(starWars, arkiv.finnFilm(3));
        assertSame(matrix, arkiv.finnFilm(4));
    }

    @Test
    void slettFilmTest() {
        Filmarkiv arkiv = new Filmarkiv(3);
        Film avatar = new Film(1, "James Cameron", "Avatar", 2011, ACTION, "Sony Pictures Imageworks");
        Film indianaJones = new Film(2, "James Cameron", "Indiana Jones", 2011, ACTION, "Sony Pictures Imageworks");
        Film starWars = new Film(3, "James Cameron", "Star Wars", 2011, ACTION, "Sony Pictures Imageworks");
        arkiv.leggTilFilm(avatar);
        arkiv.leggTilFilm(indianaJones);
        arkiv.leggTilFilm(starWars);
        assertTrue(arkiv.slettFilm(2));
    }

    @Test
    void soekTittelTest() {
        Filmarkiv arkiv = new Filmarkiv(3);
        Film avatar = new Film(1, "James Cameron", "Avatar", 2011, ACTION, "Sony Pictures Imageworks");
        arkiv.leggTilFilm(avatar);
        assertEquals(avatar, arkiv.soekTittel("Avat")[0]);
    }

    @Test
    void soekProdusentTest() {
        Filmarkiv arkiv = new Filmarkiv(3);
        Film avatar = new Film(1, "James Cameron", "Avatar", 2011, ACTION, "Sony Pictures Imageworks");
        arkiv.leggTilFilm(avatar);
        assertEquals(avatar, arkiv.soekProdusent("Camer")[0]);
    }

    @Test
    void antallSjangerTest() {
        Filmarkiv arkiv = new Filmarkiv(3);
        Film avatar = new Film(1, "James Cameron", "Avatar", 2011, ACTION, "Sony Pictures Imageworks");
        //legger film med jsanger inn
        arkiv.leggTilFilm(avatar);
        assertEquals(1, arkiv.antallSjanger(ACTION));
    }

    @Test
    void antallTest() {
        Filmarkiv arkiv = new Filmarkiv(3);
        Film avatar = new Film(1, "James Cameron", "Avatar", 2011, ACTION, "Sony Pictures Imageworks");
        arkiv.leggTilFilm(avatar);
        assertEquals(1, arkiv.antall());
    }

    //filmarkiv2
    /*
    @Test
     void finnFilmTest() {
        Filmarkiv2 arkiv = new Filmarkiv2();
        assertNull(arkiv.finnFilm(3));
    }

    @Test
    void leggTilFilmTest() {
        Filmarkiv2 arkiv = new Filmarkiv2();
        Film avatar = new Film(1, "James Cameron", "Avatar", 2011, ACTION, "Sony Pictures Imageworks");
        arkiv.leggTilFilm(avatar);
        assertEquals(avatar, arkiv.finnFilm(1));
    }

    @Test
    void forMangeFilmerTest() {
        Filmarkiv2 arkiv = new Filmarkiv2();
        Film avatar = new Film(1, "James Cameron", "Avatar", 2011, ACTION, "Sony Pictures Imageworks");
        Film indianaJones = new Film(2, "James Cameron", "Indiana Jones", 2011, ACTION, "Sony Pictures Imageworks");
        Film starWars = new Film(3, "James Cameron", "Star Wars", 2011, ACTION, "Sony Pictures Imageworks");
        Film matrix = new Film(4, "Wachowski", "The Matrix", 1999, ACTION, "Sony Pictures Imageworks");
        arkiv.leggTilFilm(avatar);
        arkiv.leggTilFilm(indianaJones);
        arkiv.leggTilFilm(starWars);

        //trigger
        arkiv.leggTilFilm(matrix);
        //sjekker riktig antall
        assertEquals(4, arkiv.antall());
        //alle gamle bevart
        assertSame(avatar, arkiv.finnFilm(1));
        assertSame(indianaJones, arkiv.finnFilm(2));
        assertSame(starWars, arkiv.finnFilm(3));
        assertSame(matrix, arkiv.finnFilm(4));
    }

    @Test
    void slettFilmTest() {
        Filmarkiv2 arkiv = new Filmarkiv2();
        Film avatar = new Film(1, "James Cameron", "Avatar", 2011, ACTION, "Sony Pictures Imageworks");
        Film indianaJones = new Film(2, "James Cameron", "Indiana Jones", 2011, ACTION, "Sony Pictures Imageworks");
        Film starWars = new Film(3, "James Cameron", "Star Wars", 2011, ACTION, "Sony Pictures Imageworks");
        arkiv.leggTilFilm(avatar);
        arkiv.leggTilFilm(indianaJones);
        arkiv.leggTilFilm(starWars);
        assertTrue(arkiv.slettFilm(2));
    }

    @Test
    void soekTittelTest() {
        Filmarkiv2 arkiv = new Filmarkiv2();
        Film avatar = new Film(1, "James Cameron", "Avatar", 2011, ACTION, "Sony Pictures Imageworks");
        arkiv.leggTilFilm(avatar);
        assertEquals(avatar, arkiv.soekTittel("Avat")[0]);
    }

    @Test
    void soekProdusentTest() {
        Filmarkiv2 arkiv = new Filmarkiv2();
        Film avatar = new Film(1, "James Cameron", "Avatar", 2011, ACTION, "Sony Pictures Imageworks");
        arkiv.leggTilFilm(avatar);
        assertEquals(avatar, arkiv.soekProdusent("Camer")[0]);
    }

    @Test
    void antallSjangerTest() {
        Filmarkiv2 arkiv = new Filmarkiv2();
        Film avatar = new Film(1, "James Cameron", "Avatar", 2011, ACTION, "Sony Pictures Imageworks");
        //legger film med jsanger inn
        arkiv.leggTilFilm(avatar);
        assertEquals(1, arkiv.antallSjanger(ACTION));
    }

    @Test
    void antallTest() {
        Filmarkiv2 arkiv = new Filmarkiv2();
        Film avatar = new Film(1, "James Cameron", "Avatar", 2011, ACTION, "Sony Pictures Imageworks");
        arkiv.leggTilFilm(avatar);
        assertEquals(1, arkiv.antall());
    }
*/



}
