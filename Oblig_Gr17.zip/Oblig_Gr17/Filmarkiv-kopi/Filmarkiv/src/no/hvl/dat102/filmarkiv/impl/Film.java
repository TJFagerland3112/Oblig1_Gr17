package no.hvl.dat102.filmarkiv.impl;

import java.util.Objects;

public class Film {

    private int filmNr;
    private String produsent;
    private String filmNavn;
    private int aar;
    private Sjanger.sjanger filmSjanger;
    private String selskap;


    public Film (int filmNr, String produsent, String filmNavn, int aar, Sjanger.sjanger filmSjanger, String selskap) {
        this.filmNr = filmNr;
        this.produsent = produsent;
        this.filmNavn = filmNavn;
        this.aar = aar;
        this.filmSjanger = filmSjanger;
        this.selskap = selskap;

    };

    public int getFilmNr() {
        return filmNr;
    }

    public void setFilmNr(int filmNr) {
        this.filmNr = filmNr;
    }

    public String getProdusent() {
        return produsent;
    }

    public void setProdusent (String produsent) {
        this.produsent = produsent;
    }

    public String getFilmNavn () {
        return filmNavn;
    }

    public void setFilmNavn(String filmNavn) {
        this.filmNavn = filmNavn;
    }

    public int getAar() {
        return aar;
    }

    public void setAar(int aar) {
        this.aar = aar;
    }

    public Sjanger.sjanger getSjanger() {
        return filmSjanger;
    }

    public void setSjanger(Sjanger.sjanger filmSjanger) {
        this.filmSjanger = filmSjanger;
    }

    public String getSelskap() {
        return selskap;
    }

    public void setSelskap(String selskap) {
        this.selskap = selskap;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Film film = (Film) o;
        return filmNr == film.filmNr && aar == film.aar && Objects.equals(produsent, film.produsent) && Objects.equals(filmNavn, film.filmNavn) && filmSjanger == film.filmSjanger && Objects.equals(selskap, film.selskap);
    }

    @Override
    public int hashCode() {
        return Objects.hash(filmNr, produsent, filmNavn, aar, filmSjanger, selskap);
    }
}
