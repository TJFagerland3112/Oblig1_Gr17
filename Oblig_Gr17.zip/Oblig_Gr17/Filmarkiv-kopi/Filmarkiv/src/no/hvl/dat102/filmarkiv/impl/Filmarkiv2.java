package no.hvl.dat102.filmarkiv.impl;

import no.hvl.dat102.filmarkiv.adt.FilmarkivADT;

public class Filmarkiv2 implements FilmarkivADT {
    private int antall;
    private LinearNode<Film> start;

    public Filmarkiv2() {
        this.antall = 0;
        this.start = null;
    }




    @Override
    public Film finnFilm(int nr) {
        LinearNode<Film> antall = start;
        while (antall != null) {
            if (antall.getData().getFilmNr() == nr) {
                return antall.getData();
            }
            antall = antall.neste;
        }
        return null;
    }

    @Override
    public void leggTilFilm(Film nyFilm) {
        LinearNode<Film> nyNode = new LinearNode<>(nyFilm);
        nyNode.neste = start; // Den nye noden peker på den som var først
        start = nyNode;       // Oppdaterer start til å være den nye noden
        antall++;
    }

    @Override
    public boolean slettFilm(int filmnr) {
        if (start == null) return false;

        if (start.data.getFilmNr() == filmnr) {
            start = start.neste; // Flytt start til den andre noden
            antall--;
            return true;
        }

        LinearNode<Film> forrige = start;
        LinearNode<Film> aktuell = start.neste;

        while (aktuell != null) {
            if (aktuell.data.getFilmNr() == filmnr) {
                // "Klipp ut" den aktuelle noden ved å koble forrige til den neste
                forrige.neste = aktuell.neste;
                antall--;
                return true;
            }
            forrige = aktuell;
            aktuell = aktuell.neste;
        }
        return false;
    }

    @Override
    public Film[] soekTittel(String delstreng) {
        Film[] treff = new Film[antall];
        int i = 0;
        LinearNode<Film> aktuell = start;

        while (aktuell != null) {
            if (aktuell.data.getFilmNavn().contains(delstreng) || aktuell.data.getFilmNavn().toLowerCase().startsWith(delstreng)) {
                treff[i] = aktuell.data;
                i++;
            }
            aktuell = aktuell.neste;
        }
        return trimTab(treff, i);
    }

    @Override
    public Film[] soekProdusent(String delstreng) {
        Film[] treff = new Film[antall];
        int i = 0;
        LinearNode<Film> aktuell = start;

        while (aktuell != null) {
            if (aktuell.data.getProdusent().contains(delstreng) || aktuell.data.getProdusent().toLowerCase().startsWith(delstreng)) {
                treff[i] = aktuell.data;
                i++;
            }
            aktuell = aktuell.neste;
        }
        return trimTab(treff, i);
    }

    @Override
    public int antallSjanger(Sjanger.sjanger sjanger) {
        int teller = 0;
        LinearNode<Film> aktuell = start;
        while (aktuell != null) {
            if (aktuell.data.getSjanger() == sjanger) {
                teller++;
            }
            aktuell = aktuell.neste;
        }
        return teller;
    }

    @Override
    public int antall() {
        return antall;
    }

    private Film[] trimTab(Film[] tab, int n) {
        Film[] nytab = new Film[n];
        int i = 0;
        while (i < n) {
            nytab[i] = tab[i];
            i++;
        }
        return nytab;
    }
}
