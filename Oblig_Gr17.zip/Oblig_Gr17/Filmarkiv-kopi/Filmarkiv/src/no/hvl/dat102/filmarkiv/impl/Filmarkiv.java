package no.hvl.dat102.filmarkiv.impl;

import no.hvl.dat102.filmarkiv.adt.FilmarkivADT;

import static no.hvl.dat102.filmarkiv.impl.Sjanger.sjanger.finnSjanger;

public class Filmarkiv implements FilmarkivADT {

    private Film[] arkiv;
    private int antall;

    public Filmarkiv (int maksAntall) {
        this.arkiv = new Film[maksAntall];
        this.antall = 0;
    }

    @Override
    public Film finnFilm(int nr) {
        for (int i = 0; i < antall; i++) {
            if (arkiv[i].getFilmNr() == nr) {
                return arkiv[i];
            }
        }
        return null;
    }

    @Override
    public void leggTilFilm(Film nyFilm) {
        if (antall >= arkiv.length) {
            arkiv = nyTab(arkiv, antall);
        }
            arkiv[antall] = nyFilm;
            antall++;

    }

    @Override
    public boolean slettFilm(int filmnr) {
        for (int i = 0; i < antall; i++) {
            if (arkiv[i].getFilmNr() == filmnr) {
                arkiv[i] = arkiv[antall-1];
                arkiv[antall-1] = null;
                antall--;
                return true;
            }
        }
        return false;
    }

    @Override
    public Film[] soekTittel(String delstreng) {
        if (delstreng == null) {
            return new Film[0];
        }

        int antallFilmer = 0;
        Film[] tittelTab = new Film[antall];
        for (int i = 0; i < antall; i++) {
            String navn = arkiv[i].getFilmNavn();
            if (navn.contains(delstreng) || navn.toLowerCase().startsWith(delstreng)) {
                tittelTab[antallFilmer] = arkiv[i];
                antallFilmer++;
            }
        }
        return trimTab(tittelTab, antallFilmer);
    }

    @Override
    public Film[] soekProdusent(String delstreng) {
        if (delstreng == null) {
            return new Film[0];
        }

        int antallProd = 0;
        Film[] prodTab = new Film[antall];
        for (int i = 0; i < antall; i++) {
            String navn = arkiv[i].getProdusent();
            if (navn.contains(delstreng.toLowerCase()) || navn.toLowerCase().startsWith(delstreng)) {
                prodTab[antallProd] = arkiv[i];
                antallProd++;
            }
        }
        return trimTab(prodTab, antallProd);
    }

    @Override
    public int antallSjanger(Sjanger.sjanger sjanger) {
        String navn = sjanger.toString();
        int antallFilmer = 0;
        for (int i = 0; i < antall; i++) {
            if (arkiv[i].getSjanger() == finnSjanger(navn)) {
                antallFilmer++;
            }
        }
        return antallFilmer;
    }

    @Override
    public int antall() {
        return antall;
    }

    private Film[] trimTab(Film[] tab, int n) {
        Film[] nytab = new Film[n];
        int i = 0;
        while (i < n) {
            nytab[i] = tab[i];
            i++;
        }
        return nytab;
    }

    private Film[] nyTab(Film[] tab, int antall) {
        Film[] arkiv2 = new Film[antall * 2];
        System.arraycopy(arkiv, 0, arkiv2, 0, arkiv.length);
        return arkiv2;
    }

}
